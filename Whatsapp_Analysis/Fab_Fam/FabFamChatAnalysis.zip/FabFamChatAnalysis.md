
# WHATSAPP GROUP CHAT ANALYSIS FOR FABULOUS FAMILY
My cousins family whatsapp group.
This project is to understand how we communicate and the sentiment that defins the chats. 
Lets Start!


```python
#Import the text file we shall be using
#from google.colab import files
#chat = files.upload()
```

Install required packages


```python
#!pip install emoji
#!pip install dateparser
#!pip install jovian
```

Import all required packages for the project


```python
import re
import matplotlib.pyplot as plot
import pandas as pd
import numpy as np
import seaborn as sns
import calendar
import datetime as dt
from wordcloud import WordCloud, STOPWORDS
from collections import Counter
import emoji
from sklearn.feature_extraction.text import CountVectorizer
import random
from textblob import TextBlob
from sklearn.decomposition import LatentDirichletAllocation
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import NMF

sns.set(rc={'figure.figsize':(14, 6)})
```

# Data Cleaning


```python
def startsWithDate(s):
    pattern = '^([0-2][0-9]|(3)[0-1])(\/)(((0)[0-9])|((1)[0-2]))(\/)(\d{2}|\d{4}), ([0-9][0-9]):([0-9][0-9]) -'
    result = re.match(pattern, s)
    if result:
        return True
    return False
```


```python
def startsWithAuthor(s):
    patterns = [
        '([\w]+):',                        # First Name
        '([\w]+[\s]+[\w]+):',              # First Name + Last Name
        '([\w]+[\s]+[\w]+[\s]+[\w]+):',    # First Name + Middle Name + Last Name
        '^(\+\d{1,2}\s)?\(?\d{3}\) ((\(\d{3}\) ?)|(\d{3}-))?\d{3}-\d{4}:',   # Mobile Number (US)
        '([+]\d{2} \d{4} \d{6}):',         # Mobile Number (Europe)
        '([+]\d{3} \d{3} \d{6})'           # Mobile Number (Uganda)
    ]
    pattern = '^' + '|'.join(patterns)
    result = re.match(pattern, s)
    if result:
        return True
    return False
```


```python
def getDataPoint(line):
    splitLine = line.split(' - ') # splitLine = ['18/06/17, 22:47', 'Loki: Why do you have 2 numbers, Banner?']
    
    dateTime = splitLine[0] # dateTime = '18/06/17, 22:47'
    
    #date, time = dateTime.split(', ') # date = '18/06/17'; time = '22:47'
    
    message = ' '.join(splitLine[1:]) # message = 'Loki: Why do you have 2 numbers, Banner?'
    
    if startsWithAuthor(message): # True
        splitMessage = message.split(': ') # splitMessage = ['Loki', 'Why do you have 2 numbers, Banner?']
        author = splitMessage[0] # author = 'Loki'
        message = ' '.join(splitMessage[1:]) # message = 'Why do you have 2 numbers, Banner?'
    else:
        author = None
    return dateTime, author, message
```

Parse the entire file and handle multi-line messages


```python
parsedChat = []
convoPath = './fab_fam.txt'
with open(convoPath, encoding='utf-8') as fp:
    fp.readline
    messageBuffer = []
    dateTime, author = None, None

    while True:
        line = fp.readline()
        if not line:
            break
        line = line.strip()
        if startsWithDate(line):
            if len(messageBuffer) > 0:
                parsedChat.append([dateTime, author, ' '.join(messageBuffer)])
                messageBuffer.clear()
                dateTime, author, message = getDataPoint(line)
                messageBuffer.append(message)
            else:
                messageBuffer.append(line)   
```


```python
df = pd.DataFrame(parsedChat, columns=['DateTime', 'Author', 'Message'])
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DateTime</th>
      <th>Author</th>
      <th>Message</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>None</td>
      <td>None</td>
      <td>26/12/2017, 12:28 - Pauline: Lena and Pauline ...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>26/12/2017, 15:58</td>
      <td>Joanna</td>
      <td>Testing 3-5 outdoor venues by night today and ...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>26/12/2017, 22:45</td>
      <td>Joanna</td>
      <td>&lt;Media omitted&gt;</td>
    </tr>
    <tr>
      <th>3</th>
      <td>28/12/2017, 21:14</td>
      <td>Micheal</td>
      <td>It will happen to you</td>
    </tr>
    <tr>
      <th>4</th>
      <td>28/12/2017, 21:39</td>
      <td>+256 792 754083</td>
      <td>See yourself</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DateTime</th>
      <th>Author</th>
      <th>Message</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>7329</th>
      <td>25/12/2019, 12:40</td>
      <td>Fina</td>
      <td>Beautiful.</td>
    </tr>
    <tr>
      <th>7330</th>
      <td>25/12/2019, 13:20</td>
      <td>Joanna</td>
      <td>Thank you😊🌹❤</td>
    </tr>
    <tr>
      <th>7331</th>
      <td>25/12/2019, 13:20</td>
      <td>Joanna</td>
      <td>🤨🤔</td>
    </tr>
    <tr>
      <th>7332</th>
      <td>25/12/2019, 18:47</td>
      <td>Olivia Namulindwa</td>
      <td>Merry Christmas Family🎄🎁 💝</td>
    </tr>
    <tr>
      <th>7333</th>
      <td>26/12/2019, 16:58</td>
      <td>Ben</td>
      <td>&lt;Media omitted&gt;</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DateTime</th>
      <th>Author</th>
      <th>Message</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>7333</td>
      <td>6882</td>
      <td>7334</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>5662</td>
      <td>35</td>
      <td>4929</td>
    </tr>
    <tr>
      <th>top</th>
      <td>15/12/2019, 08:10</td>
      <td>Joanna</td>
      <td>&lt;Media omitted&gt;</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>26</td>
      <td>1300</td>
      <td>1604</td>
    </tr>
  </tbody>
</table>
</div>




```python
#no. of images, images are represented by <media omitted>
media = df[df['Message'] == "<Media omitted>"]
media.shape
```




    (1604, 3)



This runs on the basis that Media excluded after the Whatsapp export is what is used to determine the following stats.


```python
author_media_messages_value_counts = media['Author'].value_counts()
top_10_author_media_messages_value_counts = author_media_messages_value_counts.head(10)
top_10_author_media_messages_value_counts.plot.barh()
plot.ylabel('Author')
plot.xlabel('Media items sent')
plot.title('Most Media Items sent per Author')
```




    Text(0.5, 1.0, 'Most Media Items sent per Author')




![png](output_17_1.png)



```python
#Number of group notifications
grp_notif = df[df['Author']=="grp_notif"] 
grp_notif.shape
```




    (0, 3)




```python
message_deleted = df[df['Message'] == "This message was deleted"]
message_deleted.shape
```




    (93, 3)



Who deletes the most messages in the group.Since the new feature was announced by Whatsapp.


```python
author_messages_deleted_value_counts = message_deleted['Author'].value_counts()
top10_author_messages_deleted_value_counts = author_messages_deleted_value_counts.head(10)
top10_author_messages_deleted_value_counts.plot.barh()
plot.ylabel('Author')
plot.xlabel('Messaged Deleted')
```




    Text(0.5, 0, 'Messaged Deleted')




![png](output_21_1.png)



```python
#Drop the media ommitted messages and group notifications and deleted messages
df.drop(media.index, inplace=True)
df.drop(grp_notif.index, inplace=True)
df.drop(message_deleted.index, inplace=True)
```


```python
#Find the null values
df.isnull().sum()
```




    DateTime      1
    Author      452
    Message       0
    dtype: int64




```python
#Drop empty rows with tina
df = df.dropna()
```


```python
df.reset_index(inplace=True, drop=True)
df.shape
```




    (5185, 3)



Add the dateTime object from dateTime column


```python
df['dateTime'] = pd.to_datetime(df['DateTime'], infer_datetime_format=True)
```


```python
df['Day_of_Week'] = pd.Series(pd.Categorical(df['dateTime'].dt.weekday_name, categories=list(calendar.day_name)))
df['Hour'] = pd.Series(pd.Categorical(df['dateTime'].dt.hour))
```


```python
df = df.set_index('dateTime') 
```


```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    DatetimeIndex: 5185 entries, 2017-12-26 15:58:00 to 2019-12-25 18:47:00
    Data columns (total 5 columns):
    DateTime       5185 non-null object
    Author         5185 non-null object
    Message        5185 non-null object
    Day_of_Week    5185 non-null category
    Hour           5185 non-null category
    dtypes: category(2), object(3)
    memory usage: 173.3+ KB



```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DateTime</th>
      <th>Author</th>
      <th>Message</th>
      <th>Day_of_Week</th>
      <th>Hour</th>
    </tr>
    <tr>
      <th>dateTime</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-12-26 15:58:00</th>
      <td>26/12/2017, 15:58</td>
      <td>Joanna</td>
      <td>Testing 3-5 outdoor venues by night today and ...</td>
      <td>Tuesday</td>
      <td>15</td>
    </tr>
    <tr>
      <th>2017-12-28 21:14:00</th>
      <td>28/12/2017, 21:14</td>
      <td>Micheal</td>
      <td>It will happen to you</td>
      <td>Thursday</td>
      <td>21</td>
    </tr>
    <tr>
      <th>2017-12-28 21:39:00</th>
      <td>28/12/2017, 21:39</td>
      <td>+256 792 754083</td>
      <td>See yourself</td>
      <td>Thursday</td>
      <td>21</td>
    </tr>
    <tr>
      <th>2017-12-28 23:12:00</th>
      <td>28/12/2017, 23:12</td>
      <td>Beth</td>
      <td>23/12/2017, 23:42:10 ‪+256 701 839948‬ BEWARE....</td>
      <td>Thursday</td>
      <td>23</td>
    </tr>
    <tr>
      <th>2017-12-29 15:36:00</th>
      <td>29/12/2017, 15:36</td>
      <td>Micheal</td>
      <td>Tina ng'okaye</td>
      <td>Friday</td>
      <td>15</td>
    </tr>
  </tbody>
</table>
</div>



# Data Exploration


```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DateTime</th>
      <th>Author</th>
      <th>Message</th>
      <th>Day_of_Week</th>
      <th>Hour</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>5185</td>
      <td>5185</td>
      <td>5185</td>
      <td>5185</td>
      <td>5185</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>4309</td>
      <td>35</td>
      <td>4595</td>
      <td>7</td>
      <td>24</td>
    </tr>
    <tr>
      <th>top</th>
      <td>02/11/2018, 07:49</td>
      <td>Joanna</td>
      <td>Amen</td>
      <td>Sunday</td>
      <td>9</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>8</td>
      <td>1007</td>
      <td>35</td>
      <td>983</td>
      <td>460</td>
    </tr>
  </tbody>
</table>
</div>




```python
author_value_counts = df['Author'].value_counts()
top10_talkers = author_value_counts.head(10)
top10_talkers.plot.barh()
plot.xlabel('Number of words')
plot.ylabel('Authors')
plot.title('The Top 10 Most Talkative Persons')
```




    Text(0.5, 1.0, 'The Top 10 Most Talkative Persons')




![png](output_34_1.png)



```python
df['Date'] = df['DateTime'].apply(lambda t: t.split(',')[0])
```


```python
df.groupby('Date')['Message'].count().plot()
plot.ylabel('Number of messages')
```




    Text(0, 0.5, 'Number of messages')




![png](output_36_1.png)



```python
df['Time'] = df['DateTime'].apply(lambda t: t.split(',')[1])
```


```python
df.groupby('Time')['Message'].count().plot()
plot.ylabel('Number of messages')
```




    Text(0, 0.5, 'Number of messages')




![png](output_38_1.png)



```python
df.groupby('Hour')['Message'].count().plot()
plot.ylabel('Number of messages')
```




    Text(0, 0.5, 'Number of messages')




![png](output_39_1.png)


Let's understand the number of letters and words used by each author in each message.


```python
df['Letter_Count'] = df['Message'].apply(lambda s : len(s))
df['Word_Count'] = df['Message'].apply(lambda s : len(s.split(' ')))
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DateTime</th>
      <th>Author</th>
      <th>Message</th>
      <th>Day_of_Week</th>
      <th>Hour</th>
      <th>Date</th>
      <th>Time</th>
      <th>Letter_Count</th>
      <th>Word_Count</th>
    </tr>
    <tr>
      <th>dateTime</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-12-26 15:58:00</th>
      <td>26/12/2017, 15:58</td>
      <td>Joanna</td>
      <td>Testing 3-5 outdoor venues by night today and ...</td>
      <td>Tuesday</td>
      <td>15</td>
      <td>26/12/2017</td>
      <td>15:58</td>
      <td>86</td>
      <td>15</td>
    </tr>
    <tr>
      <th>2017-12-28 21:14:00</th>
      <td>28/12/2017, 21:14</td>
      <td>Micheal</td>
      <td>It will happen to you</td>
      <td>Thursday</td>
      <td>21</td>
      <td>28/12/2017</td>
      <td>21:14</td>
      <td>21</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2017-12-28 21:39:00</th>
      <td>28/12/2017, 21:39</td>
      <td>+256 792 754083</td>
      <td>See yourself</td>
      <td>Thursday</td>
      <td>21</td>
      <td>28/12/2017</td>
      <td>21:39</td>
      <td>12</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2017-12-28 23:12:00</th>
      <td>28/12/2017, 23:12</td>
      <td>Beth</td>
      <td>23/12/2017, 23:42:10 ‪+256 701 839948‬ BEWARE....</td>
      <td>Thursday</td>
      <td>23</td>
      <td>28/12/2017</td>
      <td>23:12</td>
      <td>67</td>
      <td>7</td>
    </tr>
    <tr>
      <th>2017-12-29 15:36:00</th>
      <td>29/12/2017, 15:36</td>
      <td>Micheal</td>
      <td>Tina ng'okaye</td>
      <td>Friday</td>
      <td>15</td>
      <td>29/12/2017</td>
      <td>15:36</td>
      <td>13</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>



Describe the continuous and discrete variables


```python
print('Total Letter count in the group:' + str(df['Letter_Count'].sum())) 
print('Total Word count in the group:' + str(df['Word_Count'].sum()))
```

    Total Letter count in the group:210965
    Total Word count in the group:38057


What is the most common number of words in a message?


```python
plot.figure(figsize=(15,2))
word_count_value_counts = df['Word_Count'].value_counts()
top40_word_count = word_count_value_counts.head(30)
top40_word_count.plot.bar()
plot.xlabel('Word Count')
plot.ylabel('Frequency')
```




    Text(0, 0.5, 'Frequency')




![png](output_46_1.png)


So who exactly writes the most letters?


```python
total_letter_count_by_author = df[['Author', 'Letter_Count']].groupby('Author').sum()
sorted_total_letter_count_by_author = total_letter_count_by_author.sort_values('Letter_Count', ascending=False)
top10_sorted_total_letter_count_grouped_by_author = sorted_total_letter_count_by_author.head(10)
top10_sorted_total_letter_count_grouped_by_author.plot.barh()
plot.xlabel('Number of Letters')
plot.ylabel('Authors')
```




    Text(0, 0.5, 'Authors')




![png](output_48_1.png)



```python
total_letter_count_by_author = df[['Author', 'Letter_Count']].groupby('Author').sum()
sorted_total_letter_count_by_author = total_letter_count_by_author.sort_values('Letter_Count', ascending=False)
sorted_total_letter_count_grouped_by_author = sorted_total_letter_count_by_author
sorted_total_letter_count_grouped_by_author.plot.barh()
plot.xlabel('Number of Letters')
plot.ylabel('Authors')
```




    Text(0, 0.5, 'Authors')




![png](output_49_1.png)


Most common number of letter per message?


```python
plot.figure(figsize=(15, 2))
letter_count_value_counts = df['Letter_Count'].value_counts()
top40_letter_count_value_counts = letter_count_value_counts.head(40)
top40_letter_count_value_counts.plot.bar()
plot.xlabel('Letter count')
plot.ylabel('Frequency')
```




    Text(0, 0.5, 'Frequency')




![png](output_51_1.png)


When was the group most active?


```python
df['Day_of_Week'].value_counts().plot.barh()
plot.xlabel('Number of Messages')
plot.ylabel('Day of the Week')
```




    Text(0, 0.5, 'Day of the Week')




![png](output_53_1.png)


Any particular dates in question?


```python
df['Date'].value_counts().head(10).plot.barh() # Top 10 Dates on which the most number of messages were sent
plot.xlabel('Number of Messages')
plot.ylabel('Date')
```




    Text(0, 0.5, 'Date')




![png](output_55_1.png)


The most active hour

The most suitable time of day to get your message replied to


```python
df['Hour'].value_counts().head(10).plot.barh() # Top 10 Times of the day at which the most number of messages were sent
plot.xlabel('Number of messages')
plot.ylabel('Hour')
```




    Text(0, 0.5, 'Hour')




![png](output_57_1.png)


When the most kaboozi happens?


```python
df['Time'].value_counts().head(10).plot.barh() # Top 10 Times of the day at which the most number of messages were sent
plot.xlabel('Number of messages')
plot.ylabel('Time')
```




    Text(0, 0.5, 'Time')




![png](output_59_1.png)


What are the most commonly used words?


```python
comment_words = ''
for val in df['Message'].values:
  val = str(val)
  tokens = val.split()

  for i in range(len(tokens)):
    tokens[i] = tokens[i].lower()

  for words in tokens:
    comment_words = comment_words + words + ''

famcloud = WordCloud(width=800, height=800).generate(comment_words)

plot.figure(figsize=(8,8))
plot.imshow(famcloud)
plot.axis('off')
plot.tight_layout()

plot.show()

```


![png](output_61_0.png)



```python
#If you wish to download the image, run the cell
famcloud.to_image()
```




![png](output_62_0.png)



Count all my most used emojis


```python
df['Author'].unique()
```




    array(['Joanna', 'Micheal', '+256 792 754083', 'Beth', 'Aunt Dora',
           'Kate', 'Anna Christine', 'TJ Musiitwa', 'Ben', 'Anthony Busulwa',
           '+1 (647) 704-2525', 'Patsy', 'Irene Nakalembe', 'Lena',
           'Olivia Namulindwa', 'Lawrence Kibuuka', 'Fina', 'Junior',
           'Julie Anna', 'Elsie Mulo', 'Tony Mulo', 'Pauline', 'Livia Livie',
           '+256 776 584356 left', 'Bengie', 'John Thomas', '+44 7525 475883',
           '+256 795 230837', '+256 776 584356', 'Jane',
           '+256 795 230837 left', 'Adela Mulo', 'Kirijja Godfrey',
           'Eric Mulo', '+256 779 228234'], dtype=object)




```python
#To find your own most used emojis, just run the above cell to find your name
# and insert it where my name is...
emoji_ctr = Counter()
emojis_list = map(lambda x: ''.join(x.split()), emoji.UNICODE_EMOJI.keys())
r = re.compile('|'.join(re.escape(p) for p in emojis_list))
for idx, row in df.iterrows():
  if row['Author'] == 'TJ Musiitwa':
    emojis_found = r.findall(row['Message'])
    for emoji_found in emojis_found:
      emoji_ctr[emoji_found] += 1
for item in emoji_ctr.most_common(10):
  print(item[0] + ' - '+ str(item[1]))      
```

    😅 - 17
    😆 - 13
    🏾 - 7
    😁 - 4
    👀 - 3
    👏 - 2
    🤷 - 2
    ♂ - 2
    🤣 - 2
    🕺 - 1



```python
def extract_emojis(str):
  return ''.join(c for c in str if c in emoji.UNICODE_EMOJI)
```


```python
len(set(df['Message'].apply(lambda x: extract_emojis(x)).sum()))
```




    221



Find out the group's top 20 emoji usage


```python
emojiGrpCtr = Counter()
emojis_list = map(lambda x: ''.join(x.split()), emoji.UNICODE_EMOJI.keys())
r = re.compile('|'.join(re.escape(p) for p in emojis_list))
for idx, row in df.iterrows():
    emojis_found = r.findall(row['Message'])
    for emoji_found in emojis_found:
      emojiGrpCtr[emoji_found] += 1
for item in emojiGrpCtr.most_common(20):
  print(item[0] + ' - '+ str(item[1]))   
```

    🤣 - 797
    😂 - 627
    🤗 - 466
    😘 - 318
    🏽 - 302
    ❤ - 223
    😍 - 198
    👏 - 163
    🏾 - 153
    🎉 - 103
    ♀ - 93
    🙏 - 80
    😊 - 73
    🎂 - 66
    🥰 - 61
    🏃 - 57
    💃 - 56
    🙆 - 54
    🏼 - 51
    🤔 - 50



```python
emojiGrp = pd.DataFrame.from_dict(emojiGrpCtr, orient='index').reset_index()
```


```python
emojiGrp = emojiGrp.rename(columns={'index':'Emoji', 0:'Count'})
```


```python
emojiGrp.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Emoji</th>
      <th>Count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>👀</td>
      <td>16</td>
    </tr>
    <tr>
      <th>1</th>
      <td>🤙</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>😂</td>
      <td>627</td>
    </tr>
    <tr>
      <th>3</th>
      <td>🎵</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>🎶</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>



# Data Analysis

This section is going to cover understanding the text that flows in the group conversations with topic modeling and the like

Topic Modeling

##Latent Dirichlet Allocation


```python
count_vect = CountVectorizer(max_df=0.8, min_df=2, stop_words='english')
term_matrix = count_vect.fit_transform(df['Message'].values.astype('U'))
```


```python
term_matrix
```




    <5185x2140 sparse matrix of type '<class 'numpy.int64'>'
    	with 16469 stored elements in Compressed Sparse Row format>




```python
LDA = LatentDirichletAllocation(n_components=10,random_state=43)
LDA.fit(term_matrix)
```




    LatentDirichletAllocation(batch_size=128, doc_topic_prior=None,
                              evaluate_every=-1, learning_decay=0.7,
                              learning_method='batch', learning_offset=10.0,
                              max_doc_update_iter=100, max_iter=10,
                              mean_change_tol=0.001, n_components=10, n_jobs=None,
                              perp_tol=0.1, random_state=43, topic_word_prior=None,
                              total_samples=1000000.0, verbose=0)




```python
for i in range(10):
  random_id = random.randint(0,len(count_vect.get_feature_names()))
  print(count_vect.get_feature_names()[random_id])
```

    chartered
    trillion
    pa
    jonathan
    lost
    5th
    security
    lot
    kebba
    40



```python
first_topic = LDA.components_[0]
top_topic_words = first_topic.argsort()[-10:]
```


```python
for i in top_topic_words:
    print(count_vect.get_feature_names()[i])
```

    got
    christmas
    sorry
    family
    eh
    guys
    lovely
    just
    beautiful
    ben



```python
for i,topic in enumerate(LDA.components_):
    print(f'Top 10 words for topic #{i}:')
    print([count_vect.get_feature_names()[i] for i in topic.argsort()[-10:]])
    print('\n')
```

    Top 10 words for topic #0:
    ['got', 'christmas', 'sorry', 'family', 'eh', 'guys', 'lovely', 'just', 'beautiful', 'ben']
    
    
    Top 10 words for topic #1:
    ['kitalo', 'https', 'jose', 'hi', 'joan', 'baby', 'dear', 'bambi', 'irene', 'thanks']
    
    
    Top 10 words for topic #2:
    ['waiting', 'end', 'just', 'mu', 'shall', 'month', 'jesus', 'lena', 'amen', 'thank']
    
    
    Top 10 words for topic #3:
    ['sad', 'news', 'jt', 'really', 'uganda', 'people', 'party', 'time', 'kate', 'congratulations']
    
    
    Top 10 words for topic #4:
    ['jane', 'goddy', 'josie', 'anniversary', 'livia', 'elsie', 'lol', 'tony', 'birthday', 'happy']
    
    
    Top 10 words for topic #5:
    ['hun', 'thanx', 'look', 'need', 'like', 'nice', 'soul', 'joanna', 'rest', 'peace']
    
    
    Top 10 words for topic #6:
    ['meeting', 'hbd', 'joana', 'family', 'congrats', 'beth', 'solomon', 'thomas', 'morning', 'good']
    
    
    Top 10 words for topic #7:
    ['just', 'bless', 'great', 'good', 'don', 'lord', 'oh', 'haha', 'yes', 'god']
    
    
    Top 10 words for topic #8:
    ['week', 'hahaha', 'family', 'like', 'people', 'olivia', 'new', 'year', 'know', 'love']
    
    
    Top 10 words for topic #9:
    ['julie', 'tina', 'katie', 'patsy', 'michael', 'anna', 'love', 'day', 'birthday', 'happy']
    
    


##Non-Negative Matrix Factorization (NMF)


```python
fam_vect = TfidfVectorizer(max_df=0.8, min_df=2, stop_words='english')
doc_matrix = fam_vect.fit_transform(df['Message'].values.astype('U'))
```


```python
fam_nmf = NMF(n_components=10, random_state=42)
fam_topics = fam_nmf.fit(doc_matrix)
```


```python
t = np.argmax(fam_topics)
```


```python
fab_topic = fam_nmf.components_[0]
topic_words = fab_topic.argsort()[-10:]
for i in topic_words:
    print(fam_vect.get_feature_names()[i])
```

    josie
    irene
    goddy
    julie
    eric
    anna
    jane
    livia
    birthday
    happy



```python
for i,topic in enumerate(fam_nmf.components_):
    print(f'Top 10 words for topic #{i}:')
    print([fam_vect.get_feature_names()[i] for i in topic.argsort()[-10:]])
    print('\n')
```

    Top 10 words for topic #0:
    ['josie', 'irene', 'goddy', 'julie', 'eric', 'anna', 'jane', 'livia', 'birthday', 'happy']
    
    
    Top 10 words for topic #1:
    ['michael', 'honey', 'solomon', 'ben', 'joanna', 'adela', 'elsie', 'lena', 'irene', 'thank']
    
    
    Top 10 words for topic #2:
    ['michael', 'adela', 'irene', 'guys', 'lena', 'joanna', 'patsy', 'anna', 'elsie', 'thanks']
    
    
    Top 10 words for topic #3:
    ['chribi', 'khate', 'anna', 'mercy', 'maama', 'lord', 'kate', 'tina', 'jesus', 'amen']
    
    
    Top 10 words for topic #4:
    ['tina', 'blessings', 'lots', 'day', 'guys', 'patsy', 'family', 'beautiful', 'thanx', 'love']
    
    
    Top 10 words for topic #5:
    ['sad', 'kitalo', 'condolences', 'oh', 'bambi', 'continue', 'nct', 'soul', 'rest', 'peace']
    
    
    Top 10 words for topic #6:
    ['fab', 'looking', 'people', 'time', 'god', 'day', 'family', 'night', 'morning', 'good']
    
    
    Top 10 words for topic #7:
    ['hope', 'joanna', 'person', 'sorry', 'thomas', 'hbd', 'agaba', 'happy', 'birthday', 'tony']
    
    
    Top 10 words for topic #8:
    ['congrats', 'dear', 'oh', 'wow', 'kate', 'jt', 'thomas', 'joanna', 'congratulations', 'olivia']
    
    
    Top 10 words for topic #9:
    ['jonah', 'wonder', 'ye', 'happiness', 'years', 'did', 'joanna', 'pauline', 'ben', 'lol']
    
    


##Sentiment Analysis


```python
df['Polarity'] = df['Message'].map(lambda text: TextBlob(text).sentiment.polarity)
```

Randomly select 5 reviews with the highest positive sentiment polarity score 


```python
print('5 random reviews with the highest positive sentiment polarity: \n')
cl = df.loc[df['Polarity'] == 1, ['Message']].sample(5).values
for c in cl:
    print(c[0])
```

    5 random reviews with the highest positive sentiment polarity: 
    
    Happy birthday Beth!
    Happy birthday Tony!!!
    Happy anniversary!
    Happy Birthday Maama Dora!! 💝
    Happy birthday Irene! 🤗🤗😘


Randomly select 5 reviews with the most neutral sentiment polarity score 


```python
print('5 random reviews with the most neutral sentiment(zero) polarity: \n')
cl = df.loc[df['Polarity'] == 0, ['Message']].sample(5).values
for c in cl:
    print(c[0])
```

    5 random reviews with the most neutral sentiment(zero) polarity: 
    
    👆🏾not my words, sent as received
    CAN A CHRISTIAN DRINK ALCOHOL? Pro 31  2 7
    🎂Happy birthday Livia🎂
    🤗🤗🤗
    What time?



```python
print('5 reviews with the most negative polarity: \n')
cl = df.loc[df['Polarity'] == -0.50, ['Message']].sample(5).values
for c in cl:
    print(c[0])
```

    5 reviews with the most negative polarity: 
    
    Wrong forum 😎😎😎
    Really sad
    I feel so sad.
    Sorry may
    Bambi sad. may her soul rest in peace


The distribution of review sentiment polarity score


```python
plot.hist('Polarity', data=df)
```




    (array([2.000e+00, 1.100e+01, 5.900e+01, 7.800e+01, 9.100e+01, 3.318e+03,
            2.960e+02, 3.470e+02, 1.680e+02, 8.150e+02]),
     array([-1. , -0.8, -0.6, -0.4, -0.2,  0. ,  0.2,  0.4,  0.6,  0.8,  1. ]),
     <a list of 10 Patch objects>)




![png](output_97_1.png)

